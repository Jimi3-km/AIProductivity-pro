# AIProductivity Pro

An AI-powered productivity coach that helps you stay on track with your habits using motivation and NLP from HuggingFace models.

## Features
- Enter daily habits
- Get personalized motivation
- Built with Flask + HuggingFace + Tailwind

## Run Locally

```bash
pip install -r requirements.txt
python app.py
```

## Deployment

Recommended: Render or Replit. Add environment variables:
- `SECRET_KEY`
- `HUGGINGFACE_API_KEY`