from flask import Flask, render_template, request, redirect, session
import os
from huggingface_hub import InferenceApi

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev")

HUGGINGFACE_API_KEY = os.environ.get("HUGGINGFACE_API_KEY")
model = InferenceApi(repo_id="gpt2", token=HUGGINGFACE_API_KEY)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    habit = request.form.get("habit")
    response = model(inputs=f"Motivate me to: {habit}")
    output = response.get("generated_text", "Stay strong! Keep pushing!")
    return render_template("index.html", output=output)

if __name__ == "__main__":
    app.run(debug=True)